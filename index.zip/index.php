<html>
  <body>
    <h1>halloooo radiitttttt!!!</h1>
    <img src="https://c.tenor.com/Z8ezUHZzcLoAAAAC/love.gif" />
    <h1>nantiii malemm jannjiii nggaaa bikinn akuu takuutt lagiii yaaaaa???><</h1>
    <button id="btn_mau" onclick="alert('YEEEYYYY UDAAA JANJIII GABOLEE DIINGKARRIII')">Janji</button>&nbsp;
    <button id="btn_gamau" onclick="gamau(this)" style="position: absolute">
      Gamau
    </button>
  </body>
  <script>
    function gamau(id) {
      var mau = document.getElementById("btn_mau");
      var i = Math.floor(Math.random() * 300) + 1;
      var j = Math.floor(Math.random() * 100) + mau.offsetTop;
      id.style.left = i + "px";
      id.style.top = j + "px";
    }
  </script>
</html>